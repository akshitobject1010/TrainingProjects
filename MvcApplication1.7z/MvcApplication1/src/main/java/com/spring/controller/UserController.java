package com.spring.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.model.Data;

@Controller
@RequestMapping("/")
public class UserController {
	
	@RequestMapping("/")
	public String handler(Model model){
		
		Data data = new Data();
		data.setMessage("This data will goto FrontEnd");
		data.setUsername("Askhit");
		data.setDate(new Date());
		
		Data data1 = new Data();
		data1.setMessage("Welcome to MVC");
		data1.setUsername("Prince");
		data1.setDate( new Date());
		
		model.addAttribute("add", data);
		model.addAttribute("add2", data1);
		
		return "add";
	}
	

}
