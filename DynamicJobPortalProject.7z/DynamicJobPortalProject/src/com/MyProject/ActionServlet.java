package com.MyProject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActionServlet extends HttpServlet {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String gender;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		
		

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String name = request.getParameter("fname");
		String lastname = request.getParameter("lname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		out.println("====Welcome to Servlet" + " " + name + " " + lastname +"Your Application has been recieved====");
		out.println("</br>");
		out.println("==========================");
		out.println("Communication Details are" +email +"with password" +password );
		
		
		
		if (request.getParameter("male")!=null){
			gender = request.getParameter("male");
		}
		
		else if (request.getParameter("female")!=null){
			
			gender = request.getParameter("female");
		}
		else if (request.getParameter("other")!=null)
		{
			gender = request.getParameter("other");
		}
		
		else{
			gender = request.getParameter("notDisclose");
		}
		
		out.println("gender is" +gender);
		
		
		String country = request.getParameter("country");
		out.println("</br>");
		out.println("You belong to" + " " + country + " " +" region");
				
		
		
		
		
		
		
		
		
	}
	
	

}
